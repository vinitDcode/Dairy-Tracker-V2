---
name: Bhullar Dairy project layout
description: Actual paths, workflow command, env vars, and file roles for the Bhullar Dairy app — the handover docs say artifacts/bhullar-dairy but the real path is artifacts/file-viewer.
---

## Real artifact path
`artifacts/file-viewer/` — NOT `artifacts/bhullar-dairy/` (handover doc is wrong).

## Workflow command
`PORT=23225 BASE_PATH=/ pnpm --filter @workspace/file-viewer run dev`
Workflow name: "Bhullar Dairy"
waitForPort: 23225

**Why:** vite.config.ts throws if PORT or BASE_PATH env vars are missing. Must be set inline in command when creating workflow via configureWorkflow().

## File roles
- `index.html` — app shell; load order: theme-bootstrap.js → supabase-config.js → bundle JS → bundle CSS → aero.css → patch.css → genetics-boost.js (defer) → aero.js (defer) → patch-security.js (defer)
- `public/aero.css` — full design system override (neon green v10 as of Jun 28 2026)
- `public/aero.js` — ripple, shimmer, logo injection, theme sync, SW registration
- `public/theme-bootstrap.js` — runs sync before React; sets data-aero-theme + splash
- `public/patch.css` — scroll/z-index structural fixes; DO NOT MODIFY
- `public/genetics-boost.js` — injects 5 Supabase-powered modules into Genetics tab
- `public/supabase-config.js` — sets window.__BDF_SUPABASE_URL / __BDF_SUPABASE_KEY
- `public/sw.js` — Service Worker; bhullar-v8 cache; aero/patch/genetics files in BYPASS_CACHE

## Key bug fixed (Jun 28 2026)
aero.css v7 had `-webkit-text-fill-color: transparent` on all `.text-2xl/.text-3xl/.text-4xl` elements — made large numbers completely invisible. Removed in v10.
genetics-boost.js and supabase-config.js were not loaded in index.html — fixed.

## Critical rules
- Never set `-webkit-text-fill-color` on broad text selectors (hides numbers)
- patch.css must load LAST (wins cascade for scroll fixes)
- genetics-boost.js before aero.js in load order (genetics DOM must exist before aero processes it)
- Bump sw.js cache name (bhullar-vN) whenever STATIC file list changes
