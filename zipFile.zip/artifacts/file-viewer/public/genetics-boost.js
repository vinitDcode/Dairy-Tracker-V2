/* ═══════════════════════════════════════════════════════════════════════
   BHULLAR DAIRY — GENETICS INTELLIGENCE BOOST  v2  (SaaS Edition)
   8 modules · multi-tenant farm context · offline queue · THI lockdown
   3-gen pedigree · hemisphere lactation · dry-off countdown · inventory RPC
   JSDoc typed · no external API keys in client
   ════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  /* ── CONSTANTS ──────────────────────────────────────────────────────── */
  var SBURL          = (window.__BDF_SUPABASE_URL  || '').replace(/\/$/, '');
  var SBKEY          = window.__BDF_SUPABASE_KEY   || '';
  var EDGE_WEATHER   = SBURL + '/functions/v1/weather-proxy';

  var DEFAULT_FARM   = { id: '00000000-0000-0000-0000-000000000001', name: 'Bhullar Dairy', latitude: 30.9, longitude: 75.8, timezone: 'Asia/Kolkata' };
  var THI_CACHE_KEY  = 'bdf_thi_v2';
  var THI_TTL_MS     = 30 * 60 * 1000;   // 30 minutes
  var QUEUE_KEY      = 'bdf_offline_q';
  var ALERT_FLOOR    = 0.40;
  var MIN_SAMPLES    = 3;
  var HEAT_CYCLE     = 21;

  /* Module-level cache */
  var _farm        = null;
  var _farmPromise = null;
  var _thiData     = null;

  /* ── JSDoc TYPEDEFS ─────────────────────────────────────────────────
   * @typedef {{ id:string, name:string, latitude:number, longitude:number, timezone:string }} FarmRecord
   * @typedef {{ thi:number, temp:number, humidity:number, synthetic:boolean, cachedAt:number }} THIData
   * @typedef {{ cowData:(CowRecord|null|undefined), thiSevere:boolean, lastBullId:(string|undefined) }} SharedCtx
   * @typedef {{ id:string, tag_number:string, breed:(string|null), sire_id:(string|null), calving_due_date:(string|null), milk_yield_avg:(number|null) }} CowRecord
   * @typedef {{ id:string, bull_name:string, breed:(string|null), bull_sire_id:(string|null), milk_trait_score:(number|null), units_available:number }} BullRecord
   * @typedef {{ logged_at:string, next_heat_prediction:(string|null), am_pm_flag:('AM'|'PM'|null) }} HeatLog
   */

  /* ── SUPABASE REST ──────────────────────────────────────────────────
   * @param {string} table
   * @param {string} [qs]
   * @param {{ method?:string, body?:object }} [opts]
   * @returns {Promise<any>}
   */
  function sb(table, qs, opts) {
    opts = opts || {};
    if (!SBURL || !SBKEY) return Promise.reject(new Error('Supabase not configured'));
    var method  = opts.method || 'GET';
    var url     = SBURL + '/rest/v1/' + table + (qs ? '?' + qs : '');
    var headers = {
      apikey:          SBKEY,
      Authorization:   'Bearer ' + SBKEY,
      Accept:          'application/json',
      'Content-Type':  'application/json',
    };
    if (method !== 'GET') headers['Prefer'] = 'return=representation';
    return fetch(url, {
      method: method,
      headers: headers,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    }).then(function (r) {
      if (!r.ok) return r.json().then(function (e) { throw new Error(e.message || String(r.status)); });
      return r.status === 204 ? null : r.json();
    });
  }

  /* @param {string} fn  @param {object} body  @returns {Promise<any>} */
  function rpc(fn, body) {
    if (!SBURL || !SBKEY) return Promise.reject(new Error('Supabase not configured'));
    return fetch(SBURL + '/rest/v1/rpc/' + fn, {
      method: 'POST',
      headers: { apikey: SBKEY, Authorization: 'Bearer ' + SBKEY, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then(function (r) {
      if (!r.ok) return r.json().then(function (e) { throw new Error(e.message || String(r.status)); });
      return r.json();
    });
  }

  /* ── DOM BUILDER ────────────────────────────────────────────────────
   * @param {string} tag
   * @param {string|null} [cls]
   * @param {Array<Node|string|null>} [children]
   * @param {Object<string,string>} [attrs]
   * @returns {HTMLElement}
   */
  function el(tag, cls, children, attrs) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        if (k === 'style') n.style.cssText = attrs[k];
        else if (k === 'html') n.innerHTML = attrs[k];
        else n.setAttribute(k, attrs[k]);
      });
    }
    (children || []).forEach(function (c) {
      if (c == null) return;
      n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return n;
  }

  /* ── OFFLINE QUEUE ──────────────────────────────────────────────────
   * Stores insemination POSTs when offline; flushes on reconnect.
   * Single-flight guard prevents concurrent flushes from duplicating writes.
   * Each entry carries a _dedupe UUID generated at push-time; the server
   * uses the insemination primary key (gen_random_uuid) so a second POST
   * of the same record creates a new row — we prevent double-POST here.
   */
  var Queue = {
    _flushing: false,

    all: function () {
      try { return JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]'); }
      catch (e) { return []; }
    },

    push: function (entry) {
      var q = this.all();
      // Attach a client-side dedupe key so we can skip already-attempted entries
      q.push(Object.assign({}, entry, {
        _ts:     Date.now(),
        _dedupe: Math.random().toString(36).slice(2) + Date.now(),
      }));
      localStorage.setItem(QUEUE_KEY, JSON.stringify(q));
    },

    flush: function () {
      // Single-flight lock — bail if already flushing
      if (this._flushing || !navigator.onLine) return;
      var q = this.all();
      if (!q.length) return;

      this._flushing = true;
      var self = this;
      var failed = [];
      var chain  = Promise.resolve();

      q.forEach(function (entry) {
        chain = chain.then(function () {
          if (!navigator.onLine) { failed.push(entry); return; }
          return sb(entry.table, '', { method: 'POST', body: entry.record })
            .catch(function () { failed.push(entry); });
        });
      });

      chain.then(function () {
        localStorage.setItem(QUEUE_KEY, JSON.stringify(failed));
        var flushed = q.length - failed.length;
        if (flushed > 0) console.info('[GBM] Flushed ' + flushed + ' queued insemination(s).');
      }).finally(function () {
        self._flushing = false;
      });
    },
  };

  window.addEventListener('online',  function () { Queue.flush(); });
  Queue.flush(); // attempt flush of any residual on page load

  /* ── FARM CONTEXT ───────────────────────────────────────────────────
   * @returns {Promise<FarmRecord>}
   */
  function loadFarm() {
    if (_farm) return Promise.resolve(_farm);
    if (_farmPromise) return _farmPromise;
    _farmPromise = sb('farms', 'limit=1&select=id,name,latitude,longitude,timezone')
      .then(function (rows) {
        _farm = (rows && rows[0]) ? rows[0] : DEFAULT_FARM;
        return _farm;
      })
      .catch(function () {
        _farm = DEFAULT_FARM;
        return _farm;
      });
    return _farmPromise;
  }

  /* ── THI ENGINE ─────────────────────────────────────────────────────
   * @param {number} tempC  @param {number} rh  @returns {number}
   */
  function calcTHI(tempC, rh) {
    var tempF = tempC * 1.8 + 32;
    return Math.round(tempF - (0.55 - 0.0055 * rh) * (tempF - 26));
  }

  /* @param {number} thi @returns {'ok'|'mild'|'severe'} */
  function thiLevel(thi) {
    if (thi >= 72) return 'severe';
    if (thi >= 68) return 'mild';
    return 'ok';
  }

  /* @param {number} thi @returns {string} */
  function thiColor(thi) {
    if (thi >= 72) return '#FF4444';
    if (thi >= 68) return '#FFD600';
    return '#39FF14';
  }

  /* @param {number} lat  @param {number} lon  @returns {Promise<THIData>} */
  function loadTHI(lat, lon) {
    // 1. Serve from 30-min localStorage cache
    try {
      var cached = JSON.parse(localStorage.getItem(THI_CACHE_KEY) || 'null');
      if (cached && (Date.now() - cached.cachedAt) < THI_TTL_MS) {
        _thiData = cached;
        return Promise.resolve(cached);
      }
    } catch (e) {}

    // 2. Try Edge Function (OWM key lives server-side only)
    return fetch(EDGE_WEATHER + '?lat=' + lat + '&lon=' + lon, {
      headers: { apikey: SBKEY, Authorization: 'Bearer ' + SBKEY },
    })
    .then(function (r) {
      if (!r.ok) throw new Error('weather-proxy ' + r.status);
      return r.json();
    })
    .then(function (data) {
      var result = Object.assign({}, data, { cachedAt: Date.now() });
      localStorage.setItem(THI_CACHE_KEY, JSON.stringify(result));
      _thiData = result;
      return result;
    })
    .catch(function () {
      // 3. Seasonal fallback — no external call
      var month = new Date().getMonth();
      var isSummer = (month >= 3 && month <= 6);
      var tempC = isSummer ? 42 : 18;
      var rh    = isSummer ? 32 : 68;
      var result = { thi: calcTHI(tempC, rh), temp: tempC, humidity: rh, synthetic: true, cachedAt: Date.now() };
      localStorage.setItem(THI_CACHE_KEY, JSON.stringify(result));
      _thiData = result;
      return result;
    });
  }

  /* ── DATE HELPERS ───────────────────────────────────────────────────
   * Farm-local "today" as midnight Date (avoids UTC drift)
   * @param {string} timezone  @returns {Date}
   */
  function farmToday(timezone) {
    try {
      var parts = new Intl.DateTimeFormat('en-CA', {
        timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit',
      }).formatToParts(new Date());
      var y = '', m = '', d = '';
      parts.forEach(function (p) {
        if (p.type === 'year')  y = p.value;
        if (p.type === 'month') m = p.value;
        if (p.type === 'day')   d = p.value;
      });
      return new Date(y + '-' + m + '-' + d + 'T00:00:00');
    } catch (e) {
      return new Date();
    }
  }

  /* @param {Date} date @returns {string} */
  function fmtDate(date) {
    return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  /* @param {number} thi @returns {string} "Severe"|"Mild"|"Optimal" */
  function thiLabel(thi) {
    if (thi >= 72) return 'SEVERE';
    if (thi >= 68) return 'MILD';
    return 'OPTIMAL';
  }

  /* ── COW TAG / GENETICS PANEL ───────────────────────────────────── */
  function extractCowTag() {
    var body = document.body.innerText || '';
    var m = body.match(/No Genetics Records for\s+(\S+)/i);
    if (m) return m[1].replace(/[^A-Za-z0-9\-_]/g, '');
    m = body.match(/[Gg]enetics[^\n]*?Records? for\s+(\S+)/);
    if (m) return m[1].replace(/[^A-Za-z0-9\-_]/g, '');
    var mu = window.location.href.match(/[\/=](?:cow|cattle|tag|animal)[\/=]([^\/&#?]+)/i);
    if (mu) return decodeURIComponent(mu[1]);
    var heads = document.querySelectorAll('h1,h2,h3,[class*="font-bold"],[class*="font-semibold"]');
    for (var i = 0; i < heads.length; i++) {
      var t = heads[i].textContent.trim();
      if (/^[A-Z]{2,5}[-_]?\d{2,}/.test(t) && t.length < 24) return t.split(/\s/)[0];
    }
    return null;
  }

  function findGeneticsPanel() {
    var best = null, bestDepth = 9999;
    var candidates = document.querySelectorAll('div,section,article');
    for (var i = 0; i < candidates.length; i++) {
      var c = candidates[i];
      var txt = c.textContent || '';
      if (txt.indexOf('Add Breeding Record') === -1 && txt.indexOf('Genetics Records') === -1) continue;
      var depth = 0, p = c;
      while (p && p !== document.body) { depth++; p = p.parentElement; }
      if (depth < bestDepth && c.offsetWidth > 60) { best = c; bestDepth = depth; }
    }
    return best;
  }

  /* ── RING SVG ───────────────────────────────────────────────────── */
  function buildRingSVG(daysLeft, total, urgent) {
    var r = 26, cx = 36, cy = 36;
    var circ = 2 * Math.PI * r;
    var pct  = daysLeft != null ? Math.max(0, Math.min(1, 1 - daysLeft / total)) : 0;
    var fill = (pct * circ).toFixed(1);
    var color = urgent ? 'var(--gbm-danger)'
              : (daysLeft != null && daysLeft <= 7) ? 'var(--gbm-warn)'
              : 'var(--gbm-ok)';
    var wrap = document.createElement('div');
    wrap.innerHTML =
      '<svg width="72" height="72" viewBox="0 0 72 72" style="display:block">' +
        '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="var(--gbm-ring-track)" stroke-width="5"/>' +
        '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="' + color + '" stroke-width="5"' +
          ' stroke-linecap="round" stroke-dasharray="' + fill + ' ' + circ.toFixed(1) + '"' +
          ' transform="rotate(-90 ' + cx + ' ' + cy + ')"/>' +
      '</svg>';
    return wrap;
  }

  /* ── WAIT FOR CTX HELPER ─────────────────────────────────────────── */
  function waitForCow(ctx, maxMs) {
    return new Promise(function (resolve, reject) {
      if (ctx.cowData !== undefined) return resolve();
      var elapsed = 0, interval = 100;
      var iv = setInterval(function () {
        if (ctx.cowData !== undefined) { clearInterval(iv); return resolve(); }
        elapsed += interval;
        if (elapsed >= (maxMs || 8000)) { clearInterval(iv); reject(new Error('cow data timeout')); }
      }, interval);
    });
  }

  /* ══════════════════════════════════════════════════════════════════
     MODULE 1 — DYNAMIC THI & SEMEN LOCKDOWN
     Loads cow data AND live THI simultaneously; sets ctx for all modules.
  ══════════════════════════════════════════════════════════════════ */
  function buildTHIModule(farm, cowTag, ctx) {
    var card = el('div', 'gbm-card gbm-card--thi');
    card.appendChild(el('div', 'gbm-card-title', [
      el('span', 'gbm-icon', ['🌡️']),
      el('strong', null, ['Live THI & Heat Stress']),
    ]));
    var body = el('div', 'gbm-card-body');
    var load = el('div', 'gbm-loading', ['Loading weather & THI…']);
    body.appendChild(load);
    card.appendChild(body);

    var cowPromise = cowTag
      ? sb('cattle', 'tag_number=eq.' + encodeURIComponent(cowTag) +
          '&select=id,calving_due_date,breed,milk_yield_avg,sire_id&limit=1')
      : Promise.resolve([]);

    Promise.all([
      loadTHI(farm.latitude, farm.longitude),
      cowPromise,
    ]).then(function (results) {
      var thiRes   = results[0];
      var cowRows  = results[1] || [];
      body.removeChild(load);

      // Populate shared context
      ctx.cowData = cowRows.length ? cowRows[0] : null;

      var thi   = thiRes.thi;
      var level = thiLevel(thi);
      var color = thiColor(thi);

      // THI readout row
      body.appendChild(el('div', 'gbm-row', [
        el('span', 'gbm-label', ['THI Index']),
        el('span', 'gbm-value gbm-mono gbm-thi-index', [String(thi)], { style: 'color:' + color }),
      ]));
      body.appendChild(el('div', 'gbm-row', [
        el('span', 'gbm-label', ['Status']),
        el('span', 'gbm-value gbm-mono', [thiLabel(thi)], { style: 'color:' + color }),
      ]));
      body.appendChild(el('div', 'gbm-row', [
        el('span', 'gbm-label', ['Temp / Humidity']),
        el('span', 'gbm-value gbm-mono', [thiRes.temp + '°C / ' + thiRes.humidity + '%']),
      ]));
      body.appendChild(el('div', 'gbm-row', [
        el('span', 'gbm-label', ['Source']),
        el('span', 'gbm-value', [thiRes.synthetic ? '📅 Seasonal Est.' : '🛰 Live Weather']),
      ]));

      // Gauge bar
      var gaugePct = Math.min(100, Math.max(0, Math.round((thi - 50) / 50 * 100)));
      body.appendChild(el('div', 'gbm-thi-gauge-wrap', [
        el('div', 'gbm-thi-gauge-bar', [
          el('div', 'gbm-thi-gauge-fill', null, {
            style: '--thi-w:' + gaugePct + '%;--thi-color:' + color,
          }),
        ]),
        el('div', 'gbm-thi-thresholds', [
          el('span', null, ['68']),
          el('span', null, ['72']),
        ]),
      ]));

      if (level === 'severe') {
        ctx.thiSevere = true;
        body.appendChild(el('div', 'gbm-alert gbm-alert--danger', [
          el('span', 'gbm-alert-icon', ['🔒']),
          el('div', null, [
            el('strong', null, ['Sexed Semen LOCKED — THI ≥ 72']),
            el('br'),
            'Severe heat stress impairs conception. Use conventional semen only. Activate cooling protocol immediately.',
          ]),
        ]));
      } else if (level === 'mild') {
        body.appendChild(el('div', 'gbm-alert gbm-alert--warn', [
          el('span', 'gbm-alert-icon', ['⚠️']),
          'Mild heat stress (THI 68–71). Monitor closely; consider delaying insemination.',
        ]));
      } else {
        body.appendChild(el('div', 'gbm-alert gbm-alert--ok', [
          el('span', 'gbm-alert-icon', ['✅']),
          'Optimal breeding conditions — THI ' + thi + '.',
        ]));
      }
    }).catch(function (e) {
      try { body.removeChild(load); } catch (_) {}
      ctx.cowData = null;
      body.appendChild(el('p', 'gbm-error', ['⚠ THI: ' + e.message]));
    });

    return card;
  }

  /* ══════════════════════════════════════════════════════════════════
     MODULE 2 — 3-GENERATION PEDIGREE ENGINE + SEMEN RECOMMENDATION
  ══════════════════════════════════════════════════════════════════ */
  function buildPedigreeEngine(cowTag, ctx) {
    var card = el('div', 'gbm-card gbm-card--pedigree');
    card.appendChild(el('div', 'gbm-card-title', [
      el('span', 'gbm-icon', ['🧬']),
      el('strong', null, ['3-Gen Pedigree + Semen']),
    ]));
    var body = el('div', 'gbm-card-body');
    var load = el('div', 'gbm-loading', ['Resolving 3-gen lineage…']);
    body.appendChild(load);
    card.appendChild(body);

    waitForCow(ctx, 8000)
      .then(function () {
        var cow = ctx.cowData;
        if (!cow) {
          body.removeChild(load);
          body.appendChild(el('p', 'gbm-muted', ['No cattle record.']));
          return;
        }

        /* Collect ancestor sire IDs across up to 3 generations */
        var ancestorSireIds = {};
        var pedigreeRows = [];

        // Gen 0: direct sire
        if (cow.sire_id) {
          ancestorSireIds[cow.sire_id] = true;
          pedigreeRows.push({ label: 'Sire', value: cow.sire_id });
        }

        // Resolve gen 1 (grandsire) then gen 2 (great-grandsire)
        var gen1Promise = cow.sire_id
          ? sb('cattle', 'tag_number=eq.' + encodeURIComponent(cow.sire_id) +
              '&select=sire_id,tag_number&limit=1')
          : Promise.resolve([]);

        return gen1Promise.then(function (sire1Rows) {
          var sire1 = sire1Rows && sire1Rows[0] ? sire1Rows[0].sire_id : null;
          if (sire1) {
            ancestorSireIds[sire1] = true;
            pedigreeRows.push({ label: 'Grandsire', value: sire1 });
          }

          var gen2Promise = sire1
            ? sb('cattle', 'tag_number=eq.' + encodeURIComponent(sire1) +
                '&select=sire_id,tag_number&limit=1')
            : Promise.resolve([]);

          return gen2Promise.then(function (sire2Rows) {
            var sire2 = sire2Rows && sire2Rows[0] ? sire2Rows[0].sire_id : null;
            if (sire2) {
              ancestorSireIds[sire2] = true;
              pedigreeRows.push({ label: 'Gt-Grandsire', value: sire2 });
            }

            /* Fetch available semen */
            var breed = cow.breed;
            var qs = 'select=id,bull_name,breed,bull_sire_id,milk_trait_score,units_available' +
                     '&units_available=gt.0&order=milk_trait_score.desc&limit=20';
            if (breed) qs += '&breed=eq.' + encodeURIComponent(breed);

            return sb('semen_inventory', qs).then(function (bulls) {
              body.removeChild(load);

              /* Pedigree tree display */
              if (pedigreeRows.length) {
                var tree = el('div', 'gbm-pedigree-tree');
                pedigreeRows.forEach(function (row) {
                  tree.appendChild(el('div', 'gbm-pedigree-row', [
                    el('span', 'gbm-label', [row.label]),
                    el('code', 'gbm-pedigree-id gbm-mono', [row.value]),
                  ]));
                });
                body.appendChild(tree);
              } else {
                body.appendChild(el('p', 'gbm-muted', ['No sire data on record.']));
              }

              if (!bulls || !bulls.length) {
                body.appendChild(el('p', 'gbm-muted', ['No semen in inventory' + (breed ? ' for ' + breed : '') + '.']));
                return;
              }

              var safe  = bulls.filter(function (b) { return !b.bull_sire_id || !ancestorSireIds[b.bull_sire_id]; });
              var risky = bulls.filter(function (b) { return b.bull_sire_id &&  ancestorSireIds[b.bull_sire_id]; });

              if (risky.length) {
                var excluded = Object.keys(ancestorSireIds).slice(0, 2).join(', ');
                body.appendChild(el('div', 'gbm-alert gbm-alert--danger', [
                  el('span', 'gbm-alert-icon', ['🚫']),
                  el('span', null, [
                    el('strong', null, [risky.length + ' bull(s) excluded']),
                    ' — inbreeding risk (ancestors: ' + excluded + ')',
                  ]),
                ]));
              }

              if (ctx.thiSevere) {
                body.appendChild(el('div', 'gbm-alert gbm-alert--danger', [
                  el('span', 'gbm-alert-icon', ['🔒']),
                  'Sexed semen locked — severe heat stress (THI ≥ 72).',
                ]));
              }

              if (!safe.length) {
                body.appendChild(el('p', 'gbm-muted', ['No safe bulls after inbreeding filter.']));
                return;
              }

              safe.slice(0, 3).forEach(function (bull, i) {
                var score = parseFloat(String(bull.milk_trait_score)) || 0;
                var pct   = Math.round(score * 100);
                var isSexed = (bull.bull_name || '').toLowerCase().indexOf('sexed') !== -1;
                var locked  = ctx.thiSevere && isSexed;

                var row = el('div', 'gbm-bull-row' + (i === 0 ? ' gbm-bull-row--top' : '') + (locked ? ' gbm-bull-row--locked' : ''));
                row.appendChild(el('div', 'gbm-bull-header', [
                  el('span', 'gbm-bull-rank', ['#' + (i + 1)]),
                  el('span', 'gbm-bull-name', [bull.bull_name || 'Bull #' + bull.id]),
                  el('span', 'gbm-bull-units', [bull.units_available + ' units' + (locked ? ' 🔒' : '')]),
                ]));
                row.appendChild(el('div', 'gbm-bull-meta', [
                  el('span', null, [bull.breed || '—']),
                  el('span', 'gbm-bull-score-label', ['Milk trait: ' + pct + '%']),
                ]));
                row.appendChild(el('div', 'gbm-bar-track', [
                  el('div', 'gbm-bar-fill', null, { style: '--gbm-w:' + pct + '%' }),
                ]));
                body.appendChild(row);

                if (i === 0) ctx.lastBullId = bull.id; // expose top pick for Module 7
              });
            });
          });
        });
      })
      .catch(function (e) {
        try { body.removeChild(load); } catch (_) {}
        body.appendChild(el('p', 'gbm-error', ['⚠ Pedigree: ' + e.message]));
      });

    return card;
  }

  /* ══════════════════════════════════════════════════════════════════
     MODULE 3 — HEMISPHERE-AWARE LACTATION PLANNER
  ══════════════════════════════════════════════════════════════════ */
  function buildLactationPlanner(farm, cowTag, ctx) {
    var card = el('div', 'gbm-card gbm-card--seasonal');
    card.appendChild(el('div', 'gbm-card-title', [
      el('span', 'gbm-icon', ['🌾']),
      el('strong', null, ['Lactation Planner']),
    ]));
    var body = el('div', 'gbm-card-body');
    var load = el('div', 'gbm-loading', ['Computing lactation window…']);
    body.appendChild(load);
    card.appendChild(body);

    if (!cowTag) { load.textContent = 'Cow tag not detected.'; return card; }

    waitForCow(ctx, 8000)
      .then(function () {
        body.removeChild(load);
        var cow = ctx.cowData;
        if (!cow || !cow.calving_due_date) {
          body.appendChild(el('p', 'gbm-muted', ['No calving date on record.']));
          return;
        }

        var due      = new Date(cow.calving_due_date);
        var winStart = new Date(due); winStart.setDate(winStart.getDate() + 60);
        var winEnd   = new Date(due); winEnd.setDate(winEnd.getDate() + 90);

        // Hemisphere & summer window detection
        var isNorth     = farm.latitude >= 0;
        var summerMonths = isNorth ? [4, 5, 6, 7] : [10, 11, 0, 1];

        // Check if peak window overlaps with summer
        var overlap = false;
        var check = new Date(winStart);
        while (check <= winEnd) {
          if (summerMonths.indexOf(check.getMonth()) !== -1) { overlap = true; break; }
          check.setDate(check.getDate() + 7);
        }

        [
          ['Calving Due',    fmtDate(due)],
          ['Peak Lactation', fmtDate(winStart) + ' – ' + fmtDate(winEnd)],
          ['Hemisphere',     isNorth ? '🌍 Northern' : '🌏 Southern'],
          ['Avg Yield',      cow.milk_yield_avg ? cow.milk_yield_avg + ' L/day' : '—'],
        ].forEach(function (pair) {
          body.appendChild(el('div', 'gbm-row', [
            el('span', 'gbm-label', [pair[0]]),
            el('span', 'gbm-value gbm-mono', [pair[1]]),
          ]));
        });

        if (overlap) {
          body.appendChild(el('div', 'gbm-alert gbm-alert--warn', [
            el('span', 'gbm-alert-icon', ['⚠️']),
            el('div', null, [
              el('strong', null, ['Summer Overlap — 15–25% Yield Risk']),
              el('br'),
              isNorth
                ? 'Punjab temps 40–47°C during peak lactation. Install shade, misters, and extra water before calving.'
                : 'Southern summer heat intersects peak lactation. Maximise ventilation and night feeding.',
            ]),
          ]));
        } else {
          body.appendChild(el('div', 'gbm-alert gbm-alert--ok', [
            el('span', 'gbm-alert-icon', ['✅']),
            'Peak lactation falls outside summer — optimal yield expected.',
          ]));
        }
      })
      .catch(function (e) {
        try { body.removeChild(load); } catch (_) {}
        body.appendChild(el('p', 'gbm-error', ['⚠ Lactation: ' + e.message]));
      });

    return card;
  }

  /* ══════════════════════════════════════════════════════════════════
     MODULE 4 — DRY-OFF COUNTDOWN ENGINE
     Strict 60-day dry-off prior to calving_due_date.
  ══════════════════════════════════════════════════════════════════ */
  function buildDryOffCountdown(farm, cowTag, ctx) {
    var card = el('div', 'gbm-card gbm-card--dryoff');
    card.appendChild(el('div', 'gbm-card-title', [
      el('span', 'gbm-icon', ['🛑']),
      el('strong', null, ['Dry-Off Countdown']),
    ]));
    var body = el('div', 'gbm-card-body');
    var load = el('div', 'gbm-loading', ['Calculating dry-off period…']);
    body.appendChild(load);
    card.appendChild(body);

    if (!cowTag) { load.textContent = 'Cow tag not detected.'; return card; }

    waitForCow(ctx, 8000)
      .then(function () {
        body.removeChild(load);
        var cow = ctx.cowData;
        if (!cow || !cow.calving_due_date) {
          body.appendChild(el('p', 'gbm-muted', ['No calving date — dry-off cannot be computed.']));
          return;
        }

        var due          = new Date(cow.calving_due_date);
        var dryStart     = new Date(due); dryStart.setDate(dryStart.getDate() - 60);
        var today        = farmToday(farm.timezone);
        var daysToCalve  = Math.ceil((due - today) / 86400000);
        var daysToDry    = Math.ceil((dryStart - today) / 86400000);
        var inDryPeriod  = today >= dryStart;
        var daysIntoDry  = inDryPeriod ? Math.ceil((today - dryStart) / 86400000) : 0;

        [
          ['Calving Due',   fmtDate(due)],
          ['Dry-Off Start', fmtDate(dryStart)],
          ['Days to Calve', inDryPeriod ? daysToCalve + ' day(s)' : daysToCalve + ' day(s)'],
        ].forEach(function (pair) {
          body.appendChild(el('div', 'gbm-row', [
            el('span', 'gbm-label', [pair[0]]),
            el('span', 'gbm-value gbm-mono', [pair[1]]),
          ]));
        });

        // Status ring
        var dryProgress = inDryPeriod ? Math.min(60, daysIntoDry) : 0;
        var ringEl = el('div', 'gbm-dryoff-ring-wrap', [
          buildRingSVG(60 - dryProgress, 60, inDryPeriod && daysToCalve <= 14),
          el('div', 'gbm-ring-overlay', [
            el('div', 'gbm-ring-num' + (inDryPeriod ? ' gbm-ring-num--urgent' : ''), [
              inDryPeriod ? String(daysToCalve) : String(Math.max(0, daysToDry)),
            ]),
            el('div', 'gbm-ring-sub', [inDryPeriod ? 'to calving' : 'to dry-off']),
          ]),
        ]);
        body.appendChild(ringEl);

        if (inDryPeriod) {
          body.appendChild(el('div', 'gbm-alert gbm-alert--urgent', [
            el('span', 'gbm-alert-icon', ['🛑']),
            el('div', null, [
              el('strong', null, ['DRY PERIOD — Day ' + daysIntoDry + ' of 60']),
              el('br'),
              'HALT milking now. Switch to dry-cow nutrition. Administer teat seal if not done. Calving in ' + daysToCalve + ' day(s).',
            ]),
          ]));
        } else if (daysToDry <= 7) {
          body.appendChild(el('div', 'gbm-alert gbm-alert--warn', [
            el('span', 'gbm-alert-icon', ['⚠️']),
            el('strong', null, ['Dry-off in ' + daysToDry + ' day(s). Prepare transition diet now.']),
          ]));
        } else {
          body.appendChild(el('div', 'gbm-alert gbm-alert--ok', [
            el('span', 'gbm-alert-icon', ['✅']),
            daysToDry + ' days until dry-off period begins.',
          ]));
        }
      })
      .catch(function (e) {
        try { body.removeChild(load); } catch (_) {}
        body.appendChild(el('p', 'gbm-error', ['⚠ Dry-off: ' + e.message]));
      });

    return card;
  }

  /* ══════════════════════════════════════════════════════════════════
     MODULE 5 — DYNAMIC HEAT CYCLE TRACKER  (+/- 2 day variance)
  ══════════════════════════════════════════════════════════════════ */
  function buildHeatTracker(farm, cowTag) {
    var card = el('div', 'gbm-card gbm-card--heat');
    card.appendChild(el('div', 'gbm-card-title', [
      el('span', 'gbm-icon', ['🔥']),
      el('strong', null, ['Heat Cycle Tracker']),
    ]));
    var body = el('div', 'gbm-card-body');
    var load = el('div', 'gbm-loading', ['Reading heat logs…']);
    body.appendChild(load);
    card.appendChild(body);

    if (!cowTag) { load.textContent = 'Cow tag not detected.'; return card; }

    sb('cattle', 'tag_number=eq.' + encodeURIComponent(cowTag) + '&select=id&limit=1')
      .then(function (rows) {
        if (!rows || !rows.length) throw new Error('Cow not found');
        return sb('heat_logs',
          'cattle_id=eq.' + rows[0].id +
          '&select=logged_at,next_heat_prediction,am_pm_flag&order=logged_at.desc&limit=1');
      })
      .then(function (logs) {
        body.removeChild(load);

        if (!logs || !logs.length) {
          body.appendChild(el('p', 'gbm-muted', ['No heat logs. Standard cycle is 21 days.']));
          body.appendChild(el('div', 'gbm-ring-wrap', [
            buildRingSVG(null, HEAT_CYCLE, false),
            el('div', 'gbm-ring-overlay', [
              el('div', 'gbm-ring-num', ['21']),
              el('div', 'gbm-ring-sub', ['day cycle']),
            ]),
          ]));
          return;
        }

        var log  = logs[0];
        var next = log.next_heat_prediction ? new Date(log.next_heat_prediction) : null;
        var now  = farmToday(farm.timezone);

        var daysLeft  = next ? Math.max(0, Math.ceil((next - now) / 86400000)) : null;
        var early     = daysLeft !== null ? Math.max(0, daysLeft - 2) : null;
        var late      = daysLeft !== null ? daysLeft + 2 : null;
        var urgent    = daysLeft !== null && daysLeft <= 3;

        if (urgent) {
          body.appendChild(el('div', 'gbm-alert gbm-alert--urgent', [
            el('span', 'gbm-alert-icon', ['⚡']),
            el('strong', null, ['Heat imminent in ' + daysLeft + ' day(s) — prepare AI now.']),
          ]));
        }

        var flex = el('div', 'gbm-heat-flex');
        flex.appendChild(el('div', 'gbm-ring-wrap', [
          buildRingSVG(daysLeft, HEAT_CYCLE, urgent),
          el('div', 'gbm-ring-overlay', [
            el('div', 'gbm-ring-num' + (urgent ? ' gbm-ring-num--urgent' : ''),
              [daysLeft !== null ? String(daysLeft) : '—']),
            el('div', 'gbm-ring-sub', ['days left']),
          ]),
        ]));
        flex.appendChild(el('div', 'gbm-heat-details', [
          el('div', 'gbm-row', [
            el('span', 'gbm-label', ['Next Heat']),
            el('span', 'gbm-value' + (urgent ? ' gbm-value--warn' : ''),
              [next ? fmtDate(next) : '—']),
          ]),
          el('div', 'gbm-row', [
            el('span', 'gbm-label', ['±2 Day Window']),
            el('span', 'gbm-value gbm-mono',
              [early !== null ? 'Day ' + early + '–' + late : '—']),
          ]),
          el('div', 'gbm-row', [
            el('span', 'gbm-label', ['Last Log']),
            el('span', 'gbm-value',
              [log.logged_at ? fmtDate(new Date(log.logged_at)) : '—']),
          ]),
          el('div', 'gbm-row', [
            el('span', 'gbm-label', ['Timing']),
            el('span', 'gbm-badge gbm-badge--' + (log.am_pm_flag || 'na').toLowerCase(),
              [log.am_pm_flag || '—']),
          ]),
        ]));
        body.appendChild(flex);
      })
      .catch(function (e) {
        try { body.removeChild(load); } catch (_) {}
        body.appendChild(el('p', 'gbm-error', ['⚠ Heat: ' + e.message]));
      });

    return card;
  }

  /* ══════════════════════════════════════════════════════════════════
     MODULE 6 — AM/PM AI ACTION ALERT (exact date boundaries)
  ══════════════════════════════════════════════════════════════════ */
  function buildAmPmAlert(farm, cowTag) {
    var card = el('div', 'gbm-card gbm-card--ampm');
    card.appendChild(el('div', 'gbm-card-title', [
      el('span', 'gbm-icon', ['🕐']),
      el('strong', null, ['AM / PM Action Alert']),
    ]));
    var body = el('div', 'gbm-card-body');
    var load = el('div', 'gbm-loading', ['Checking latest heat log…']);
    body.appendChild(load);
    card.appendChild(body);

    if (!cowTag) { load.textContent = 'Cow tag not detected.'; return card; }

    sb('cattle', 'tag_number=eq.' + encodeURIComponent(cowTag) + '&select=id&limit=1')
      .then(function (rows) {
        if (!rows || !rows.length) throw new Error('Cow not found');
        return sb('heat_logs',
          'cattle_id=eq.' + rows[0].id +
          '&select=am_pm_flag,logged_at,next_heat_prediction&order=logged_at.desc&limit=1');
      })
      .then(function (logs) {
        body.removeChild(load);

        if (!logs || !logs.length) {
          body.appendChild(el('div', 'gbm-ampm-idle', [
            el('div', 'gbm-ampm-big-icon', ['🌤']),
            el('p', 'gbm-muted', ['No active heat detected — monitor daily.']),
          ]));
          return;
        }

        var log  = logs[0];
        var flag = (log.am_pm_flag || '').toUpperCase();
        var isAM = flag === 'AM';

        if (flag !== 'AM' && flag !== 'PM') {
          body.appendChild(el('p', 'gbm-muted', ['Heat flag unclear: "' + flag + '"']));
          return;
        }

        // Compute exact action date in farm timezone
        var today  = farmToday(farm.timezone);
        var action = new Date(today);
        if (!isAM) action.setDate(action.getDate() + 1); // PM heat → next-day morning

        var logDate     = log.logged_at ? new Date(log.logged_at) : new Date();
        var detectIcon  = isAM ? '☀️' : '🌆';
        var actionIcon  = isAM ? '🌅' : '🌙';
        var actionLabel = isAM
          ? 'Same-day PM  · 2 – 6 PM  · ' + fmtDate(action)
          : 'Next-day AM  · 6 – 10 AM · ' + fmtDate(action);

        body.appendChild(el('div', 'gbm-ampm-banner gbm-ampm--' + flag.toLowerCase(), [
          el('div', 'gbm-ampm-detect-row', [
            el('span', 'gbm-ampm-badge', [detectIcon + ' ' + flag + ' Heat Detected']),
            el('span', 'gbm-ampm-date', [fmtDate(logDate)]),
          ]),
          el('div', 'gbm-ampm-arrow', ['↓']),
          el('div', 'gbm-ampm-action-row', [
            el('span', null, [actionIcon]),
            el('div', null, [el('strong', null, ['Schedule AI — ' + actionLabel])]),
          ]),
        ]));

        body.appendChild(el('p', 'gbm-ampm-note', [
          '💡 Optimal conception: AI performed 12 – 18 hrs after heat detection.',
        ]));
      })
      .catch(function (e) {
        try { body.removeChild(load); } catch (_) {}
        body.appendChild(el('p', 'gbm-error', ['⚠ AM/PM: ' + e.message]));
      });

    return card;
  }

  /* ══════════════════════════════════════════════════════════════════
     MODULE 7 — LOG AI & AUTO-DEDUCT INVENTORY SYNC
     Offline queue · Zod-style validation · haptic on success
  ══════════════════════════════════════════════════════════════════ */
  function buildInventorySync(farm, cowTag, ctx) {
    var card = el('div', 'gbm-card gbm-card--inventory');
    card.appendChild(el('div', 'gbm-card-title', [
      el('span', 'gbm-icon', ['💉']),
      el('strong', null, ['Log AI & Inventory Sync']),
    ]));
    var body = el('div', 'gbm-card-body');
    card.appendChild(body);

    if (!cowTag) {
      body.appendChild(el('p', 'gbm-muted', ['Cow tag not detected.']));
      return card;
    }

    var statusEl = el('div', 'gbm-inv-status');

    // Load technicians + available semen in parallel
    Promise.all([
      sb('cattle', 'tag_number=eq.' + encodeURIComponent(cowTag) + '&select=id&limit=1'),
      sb('technicians', 'select=id,name&order=name.asc'),
      sb('semen_inventory', 'units_available=gt.0&select=id,bull_name,units_available&order=bull_name.asc&limit=40'),
    ]).then(function (results) {
      var cattleRows = results[0] || [];
      var techs      = results[1] || [];
      var bulls      = results[2] || [];

      if (!cattleRows.length) {
        body.appendChild(el('p', 'gbm-muted', ['Cow not found in database.']));
        return;
      }
      var cattleId = cattleRows[0].id;

      /* Technician select (min 44px touch target) */
      var techSel = el('select', 'gbm-select');
      techSel.setAttribute('aria-label', 'Select Technician');
      techSel.appendChild(el('option', null, ['— Technician —'], { value: '' }));
      techs.forEach(function (t) {
        techSel.appendChild(el('option', null, [t.name || 'Tech'], { value: t.id }));
      });

      /* Semen select */
      var semenSel = el('select', 'gbm-select');
      semenSel.setAttribute('aria-label', 'Select Bull Semen');
      semenSel.appendChild(el('option', null, ['— Bull Semen —'], { value: '' }));

      function refreshSemenSelect(freshBulls) {
        while (semenSel.firstChild) semenSel.removeChild(semenSel.firstChild);
        semenSel.appendChild(el('option', null, ['— Bull Semen —'], { value: '' }));
        (freshBulls || []).forEach(function (b) {
          semenSel.appendChild(el('option', null, [b.bull_name + ' (' + b.units_available + ' units)'], { value: b.id }));
        });
      }
      refreshSemenSelect(bulls);

      /* Log button — 44px min touch target */
      var logBtn = el('button', 'gbm-action-btn', ['💉 Log Insemination']);
      logBtn.setAttribute('aria-label', 'Log insemination and auto-deduct semen inventory');
      logBtn.setAttribute('type', 'button');

      body.appendChild(statusEl);
      body.appendChild(el('div', 'gbm-form-group', [
        el('label', 'gbm-form-label', ['Technician']),
        techSel,
      ]));
      body.appendChild(el('div', 'gbm-form-group', [
        el('label', 'gbm-form-label', ['Bull Semen']),
        semenSel,
      ]));
      body.appendChild(logBtn);

      logBtn.addEventListener('click', function () {
        var techId  = techSel.value;
        var semenId = semenSel.value;

        /* Schema validation (Zod-style manual checks — no library needed) */
        var errors = [];
        if (!techId)  errors.push('technician required');
        if (!semenId) errors.push('bull semen required');
        if (errors.length) {
          statusEl.textContent = '⚠ ' + errors.join(' · ');
          statusEl.className = 'gbm-inv-status gbm-error';
          return;
        }

        logBtn.disabled    = true;
        logBtn.textContent = 'Logging…';
        statusEl.textContent = '';
        statusEl.className   = 'gbm-inv-status';

        var record = {
          cattle_id:      cattleId,
          technician_id:  techId,
          semen_batch_id: semenId,
          outcome:        'pending',
          ai_date:        new Date().toISOString().slice(0, 10),
          farm_id:        farm.id || DEFAULT_FARM.id,
        };

        if (!navigator.onLine) {
          /* Optimistic offline path — queue and update UI instantly */
          Queue.push({ table: 'inseminations', record: record });
          statusEl.innerHTML = '📶 <strong>Offline</strong> — insemination queued. Will sync automatically when connected.';
          statusEl.className = 'gbm-inv-status gbm-alert gbm-alert--warn';
          if (navigator.vibrate) navigator.vibrate(50);
          logBtn.disabled = false; logBtn.textContent = '💉 Log Insemination';
          return;
        }

        sb('inseminations', '', { method: 'POST', body: record })
          .then(function () {
            return rpc('decrement_semen_inventory', {
              p_semen_id: semenId,
              p_farm_id:  farm.id || DEFAULT_FARM.id,
            });
          })
          .then(function (deductRes) {
            if (navigator.vibrate) navigator.vibrate(50); // haptic
            var remaining = (deductRes && deductRes.remaining !== undefined) ? deductRes.remaining : '?';
            if (deductRes && deductRes.remaining === 0) {
              statusEl.innerHTML = '✅ Logged. <strong style="color:var(--gbm-danger)">⚠ Stock EMPTY — reorder immediately.</strong>';
            } else {
              statusEl.textContent = '✅ Logged. Inventory decremented — ' + remaining + ' units remaining.';
            }
            statusEl.className = 'gbm-inv-status gbm-alert gbm-alert--ok';

            // Refresh semen list
            return sb('semen_inventory', 'units_available=gt.0&select=id,bull_name,units_available&order=bull_name.asc&limit=40')
              .then(function (fresh) { refreshSemenSelect(fresh); });
          })
          .catch(function (e) {
            statusEl.textContent = '⚠ Error: ' + e.message;
            statusEl.className = 'gbm-inv-status gbm-error';
          })
          .finally(function () {
            logBtn.disabled    = false;
            logBtn.textContent = '💉 Log Insemination';
          });
      });
    }).catch(function (e) {
      body.appendChild(el('p', 'gbm-error', ['⚠ Inventory: ' + e.message]));
    });

    return card;
  }

  /* ══════════════════════════════════════════════════════════════════
     MODULE 8 — AI BATCH & TECH SUCCESS ANALYTICS (40% floor)
  ══════════════════════════════════════════════════════════════════ */
  function buildBatchAnalytics(farm) {
    var card = el('div', 'gbm-card gbm-card--analytics gbm-card--full');
    card.appendChild(el('div', 'gbm-card-title', [
      el('span', 'gbm-icon', ['📊']),
      el('strong', null, ['AI Batch & Tech Success Analytics']),
    ]));
    var body = el('div', 'gbm-card-body');
    var load = el('div', 'gbm-loading', ['Loading conception data…']);
    body.appendChild(load);
    card.appendChild(body);

    var insemQs = 'select=technician_id,semen_batch_id,outcome';
    if (farm.id) insemQs += '&farm_id=eq.' + farm.id;

    Promise.all([
      sb('inseminations', insemQs),
      sb('technicians', 'select=id,name'),
    ]).then(function (results) {
      var insems = results[0] || [];
      var techs  = results[1] || [];
      body.removeChild(load);

      if (!insems.length) {
        body.appendChild(el('p', 'gbm-muted', ['No insemination records found.']));
        return;
      }

      var techMap = {};
      techs.forEach(function (t) { techMap[String(t.id)] = t.name || 'Tech #' + t.id; });

      function aggregate(rows, keyFn, nameFn) {
        var map = {};
        rows.forEach(function (r) {
          var k = String(keyFn(r) || 'unknown');
          if (!map[k]) map[k] = { name: nameFn(r, k), total: 0, success: 0 };
          map[k].total++;
          var o = (r.outcome || '').toLowerCase();
          if (o === 'pregnant' || o === 'success' || o === '1' || o === 'true') map[k].success++;
        });
        return map;
      }

      function renderGroup(title, statsMap) {
        var keys = Object.keys(statsMap).sort(function (a, b) {
          return (statsMap[b].success / (statsMap[b].total || 1)) -
                 (statsMap[a].success / (statsMap[a].total || 1));
        });
        var hasAlert = keys.some(function (k) {
          var s = statsMap[k];
          return s.total >= MIN_SAMPLES && s.success / s.total < ALERT_FLOOR;
        });

        var section = el('div', 'gbm-section');
        section.appendChild(el('div', 'gbm-section-head', [
          el('span', null, [title]),
          hasAlert ? el('span', 'gbm-badge gbm-badge--alert', ['⚠ Below 40% threshold']) : null,
        ].filter(Boolean)));

        keys.forEach(function (k) {
          var s   = statsMap[k];
          var pct = s.total ? Math.round(s.success / s.total * 100) : 0;
          var low = s.total >= MIN_SAMPLES && pct / 100 < ALERT_FLOOR;

          var row = el('div', 'gbm-stat-row' + (low ? ' gbm-stat-row--alert' : ''));
          row.appendChild(el('div', 'gbm-stat-header', [
            el('span', 'gbm-stat-name', [(low ? '⚠ ' : '✓ ') + s.name]),
            el('span', 'gbm-stat-pct gbm-mono' + (low ? ' gbm-stat-pct--alert' : ''),
              [pct + '% (' + s.success + '/' + s.total + ')']),
          ]));
          row.appendChild(el('div', 'gbm-bar-track', [
            el('div', 'gbm-bar-fill' + (low ? ' gbm-bar-fill--alert' : ''), null,
              { style: '--gbm-w:' + pct + '%' }),
          ]));
          if (low) {
            row.appendChild(el('p', 'gbm-stat-warn', [
              'Rate below 40% floor. Review technique or pause batch pending quality check.',
            ]));
          }
          section.appendChild(row);
        });
        return section;
      }

      var techStats  = aggregate(insems,
        function (r) { return r.technician_id; },
        function (r, k) { return techMap[k] || 'Tech #' + k; });
      var batchStats = aggregate(insems,
        function (r) { return r.semen_batch_id; },
        function (r, k) { return 'Batch: ' + k; });

      body.appendChild(renderGroup('👨‍⚕️ Technician Performance', techStats));
      body.appendChild(el('hr', 'gbm-divider-line'));
      body.appendChild(renderGroup('🧫 Semen Batch Performance', batchStats));

      /* Export button */
      var exportBtn = el('button', 'gbm-export-btn', ['⬇ Export Analytics JSON']);
      exportBtn.setAttribute('type', 'button');
      exportBtn.addEventListener('click', function () {
        var data = {
          exported_at:       new Date().toISOString(),
          farm:              farm.name,
          technicians:       techStats,
          semen_batches:     batchStats,
          raw_inseminations: insems,
        };
        var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        var a    = document.createElement('a');
        a.href   = window.URL.createObjectURL(blob);
        a.download = 'bhullar-genetics-' + new Date().toISOString().slice(0, 10) + '.json';
        document.body.appendChild(a);
        a.click();
        setTimeout(function () { document.body.removeChild(a); window.URL.revokeObjectURL(a.href); }, 1000);
      });
      body.appendChild(exportBtn);
    }).catch(function (e) {
      try { body.removeChild(load); } catch (_) {}
      body.appendChild(el('p', 'gbm-error', ['⚠ Analytics: ' + e.message]));
    });

    return card;
  }

  /* ══════════════════════════════════════════════════════════════════
     ORCHESTRATOR — render all 8 modules with error boundary
  ══════════════════════════════════════════════════════════════════ */
  function renderModules(container) {
    if (container.querySelector('.gbm-wrapper')) return;

    var cowTag = extractCowTag();

    /* @type {SharedCtx} */
    var ctx = { cowData: undefined, thiSevere: false, lastBullId: undefined };

    var wrapper = el('div', 'gbm-wrapper');

    /* Offline banner */
    var offlineBanner = el('div', 'gbm-offline-banner' + (navigator.onLine ? ' gbm-hidden' : ''), [
      '📶 Offline mode — inseminations are queued and will sync automatically.',
    ]);
    window.addEventListener('online',  function () { offlineBanner.classList.add('gbm-hidden'); });
    window.addEventListener('offline', function () { offlineBanner.classList.remove('gbm-hidden'); });
    wrapper.appendChild(offlineBanner);

    wrapper.appendChild(el('div', 'gbm-header', [
      el('span', 'gbm-header-line'),
      el('span', 'gbm-header-text', ['Genetics Intelligence  v2']),
      el('span', 'gbm-header-line'),
    ]));

    /* Load farm context */
    loadFarm().then(function (farm) {
      /* 2×4 grid for modules 1–8 */
      var grid = el('div', 'gbm-grid');

      /* Module 1 runs first — it populates ctx.cowData used by modules 2-4 */
      var mod1 = buildTHIModule(farm, cowTag, ctx);
      var mod2 = buildPedigreeEngine(cowTag, ctx);
      var mod3 = buildLactationPlanner(farm, cowTag, ctx);
      var mod4 = buildDryOffCountdown(farm, cowTag, ctx);
      var mod5 = buildHeatTracker(farm, cowTag);
      var mod6 = buildAmPmAlert(farm, cowTag);
      var mod7 = buildInventorySync(farm, cowTag, ctx);

      [mod1, mod2, mod3, mod4, mod5, mod6, mod7].forEach(function (m) {
        if (m) grid.appendChild(m);
      });

      wrapper.appendChild(grid);

      /* Module 8 — full width */
      var mod8 = buildBatchAnalytics(farm);
      if (mod8) wrapper.appendChild(mod8);
    }).catch(function (e) {
      wrapper.appendChild(el('p', 'gbm-error', ['⚠ Could not load farm context: ' + e.message]));
    });

    container.appendChild(wrapper);
  }

  /* ══════════════════════════════════════════════════════════════════
     DETECTION — tab click + MutationObserver
  ══════════════════════════════════════════════════════════════════ */
  function tryInject() {
    var panel = findGeneticsPanel();
    if (!panel) return false;
    try { renderModules(panel); } catch (e) { console.error('[GBM]', e); }
    return true;
  }

  document.addEventListener('click', function (e) {
    var t = e.target && e.target.closest
      ? e.target.closest('[role="tab"],button,[class*="tab"]')
      : null;
    if (!t) return;
    if ((t.textContent || '').indexOf('Genetic') === -1) return;
    document.querySelectorAll('.gbm-wrapper').forEach(function (w) { w.remove(); });
    setTimeout(function () {
      if (tryInject()) return;
      var attempts = 0;
      var iv = setInterval(function () {
        if (tryInject() || ++attempts > 15) clearInterval(iv);
      }, 200);
    }, 280);
  }, true);

  new MutationObserver(function (muts) {
    for (var i = 0; i < muts.length; i++) {
      for (var j = 0; j < muts[i].addedNodes.length; j++) {
        var n = muts[i].addedNodes[j];
        if (n.nodeType !== 1) continue;
        var txt = n.textContent || '';
        if (txt.indexOf('Genetics Records') !== -1 || txt.indexOf('Add Breeding Record') !== -1) {
          setTimeout(tryInject, 120);
        }
      }
    }
  }).observe(document.body, { childList: true, subtree: true });

  setTimeout(tryInject, 600);

})();
