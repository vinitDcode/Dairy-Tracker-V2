/* ═══════════════════════════════════════════════════════════
   BHULLAR DAIRY — SERVICE WORKER  v5
   Cache-first for static assets, network-first for navigation.
   
   v5 changes: added patch.css, patch-security.js,
   theme-bootstrap.js to BYPASS_CACHE so fixes roll out
   immediately without requiring a cache-bust.
═══════════════════════════════════════════════════════════ */

var CACHE = 'bhullar-v8';
// Only cache content-hashed bundles, the app shell, and static icons.
// Enhancement/patch files are served no-cache — do NOT pre-cache them.
var STATIC = [
  '/',
  '/assets/index-CrpyjvbJ.js',
  '/assets/index-B1BBlUQ6.css',
  '/favicon.svg',
  '/icons/icon-72x72.png',
  '/icons/icon-96x96.png',
  '/icons/icon-128x128.png',
  '/icons/icon-144x144.png',
  '/icons/icon-152x152.png',
  '/icons/icon-192x192.png',
  '/icons/icon-384x384.png',
  '/icons/icon-512x512.png',
];

self.addEventListener('install', function (e) {
  e.waitUntil(
    caches.open(CACHE).then(function (c) {
      return c.addAll(STATIC);
    }).then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys.filter(function (k) { return k !== CACHE; })
            .map(function (k) { return caches.delete(k); })
      );
    }).then(function () { return self.clients.claim(); })
  );
});

// Paths that must always come from the network — never serve stale
var BYPASS_CACHE = [
  '/aero.js',
  '/aero.css',
  '/patch.css',
  '/patch-security.js',
  '/theme-bootstrap.js',
  '/manifest.json',
  '/sw.js',
];

self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // Always fetch fresh for enhancement/patch files
  if (BYPASS_CACHE.indexOf(url.pathname) !== -1) {
    e.respondWith(fetch(req));
    return;
  }

  // Navigation: network-first, cache fallback
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).then(function (res) {
        var clone = res.clone();
        caches.open(CACHE).then(function (c) { c.put(req, clone); });
        return res;
      }).catch(function () { return caches.match('/'); })
    );
    return;
  }

  // Assets: cache-first
  e.respondWith(
    caches.match(req).then(function (cached) {
      var network = fetch(req).then(function (res) {
        if (res.ok) {
          var clone = res.clone();
          caches.open(CACHE).then(function (c) { c.put(req, clone); });
        }
        return res;
      });
      return cached || network;
    })
  );
});
